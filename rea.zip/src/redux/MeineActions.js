export const actionCreators = {

    einLoggAction:(event) => {
        return {type: "hatSicheingeloggt"};
    },

    ausLoggAction: (event) => {
        return {type: "hatSichAusgeloggt"}; 
        

    }

}